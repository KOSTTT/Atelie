﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Atelie.Pages
{
    /// <summary>
    /// Логика взаимодействия для AddWind.xaml
    /// </summary>
    public partial class AddWind : Window
    {
        public AddWind()
        {
            InitializeComponent();
        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            Model.Client employee = new Model.Client();
            if (tbLastName.Text == "" || tbName.Text == "" || tbPatronymic.Text == "" || tbAdres.Text == "" || tbNumberPhon.Text == "")
            {
                MessageBox.Show("Пустые поля");
                return;
            }
            //client.LastName = tbName.Text;
            //client.Name = tbName.Text;
            //client.Patronymic = tbPatronymic.Text;
            //client.Adres = tbAdres.Text;
            //client.NumberPhon = tbNumberPhon.Text;
            //atEntities.Client.Add(client);
            //atEntities.SaveChanges();
            //MessageBox.Show("Добавлен");
            //DgClient.ItemsSource = atEntities.Client.ToList();
        }
    }
}
