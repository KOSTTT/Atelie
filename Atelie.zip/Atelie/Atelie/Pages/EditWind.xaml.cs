﻿using Atelie.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Atelie.Pages
{
    /// <summary>
    /// Логика взаимодействия для EditWind.xaml
    /// </summary>
    public partial class EditWind : Window
    {
         
        Entities1 atEntities = new Entities1();
        public EditWind()
        {
            InitializeComponent();

            var curClient = Entities1.GetContext().Client.ToList();
            DgClient.ItemsSource = curClient;
        }

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            if (tbLastName.Text == "" || tbName.Text == "" || tbPatronymic.Text == "" || tbAdres.Text == "" || tbNumberPhon.Text == "")
            {
                MessageBox.Show("Не все поля заполнены");
                return;
            }
            int id = 0;
            if (DgClient.SelectedItem == null)
            {
                MessageBox.Show("Запись была не выбрана");
                return;
            }
            try
            {
                id = atEntities.Client.ToList()[DgClient.SelectedIndex].ClientID;

            }
            catch (System.ArgumentOutOfRangeException)
            {
                MessageBox.Show("Запись была не выбрана");
                return;
            }
            Client deleteClient = atEntities.Client.Find(id);
            atEntities.Client.Remove(deleteClient);
            atEntities.SaveChanges();

            Client curClient = new Client();

            curClient.ClientID = id;
            curClient.LastName = tbLastName.Text;
            curClient.Name = tbName.Text;
            curClient.Patronymic = tbPatronymic.Text;
            curClient.Adres = tbAdres.Text;
            curClient.NumberPhon = tbNumberPhon.Text;
            atEntities.Client.Add(curClient);
            atEntities.SaveChanges();
            MessageBox.Show("Изменения сохранены");
            DgClient.ItemsSource = atEntities.Client.ToList();
        }
    }
}
