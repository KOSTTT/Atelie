﻿using Atelie.Model;
using Atelie.Pages;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Atelie
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Model.Entities1 atEntities = new Model.Entities1();
        public MainWindow()
        {
            InitializeComponent();

            var curClient = Entities1.GetContext().Client.ToList();
            DgClient.ItemsSource = curClient;
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {

            AddEditWind addeditwind = new AddEditWind();
            addeditwind.Show();
        }

        private void DgClient_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            EditWind editwind = new EditWind();
            editwind.Show();
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            int id = 0;
            if (DgClient.SelectedItem == null)
            {
                MessageBox.Show("Запись была не выбрана");
                return;
            }
            try
            {
                id = atEntities.Client.ToList()[DgClient.SelectedIndex].ClientID;

            }
            catch (System.ArgumentOutOfRangeException)
            {
                MessageBox.Show("Запись была не выбрана");
                return;
            }
            Client deleteClient = atEntities.Client.Find(id);
            atEntities.Client.Remove(deleteClient);
            atEntities.SaveChanges();
            MessageBox.Show("Запись удалена");
            DgClient.ItemsSource = atEntities.Client.ToList();
        }

        private void BtnUpdate_Click(object sender, RoutedEventArgs e)
        {
            var curClient = Entities1.GetContext().Client.ToList();
            DgClient.ItemsSource = curClient;
        }
    }
}
