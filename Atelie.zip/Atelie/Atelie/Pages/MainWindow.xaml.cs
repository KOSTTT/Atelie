﻿using Atelie.Pages;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Atelie
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Model.AtelieEntities atEntities = new Model.AtelieEntities();
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            DgClient.ItemsSource = atEntities.Client.ToList();
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
            AddWind addwind = new AddWind();
            addwind.Show();
        }

        private void DgClient_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            this.Close();
            AddWind addwind = new AddWind();
            addwind.Show();
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            int id = 0;
            if (DgClient.SelectedItem == null)
            {
                MessageBox.Show("Запись не была выбрана");
                return;
            }
            try
            {
                id = atEntities.Client.ToList()[DgClient.SelectedIndex].ClientID;

            }
            catch (System.ArgumentOutOfRangeException)
            {
                MessageBox.Show("Запись не была выбрана");
                return;
            }
            Model.Client client = atEntities.Client.Find(id);
            atEntities.Client.Remove(client);
            atEntities.SaveChanges();
            MessageBox.Show("Удален");
            DgClient.ItemsSource = atEntities.Client.ToList();
        }
    }
}
